$(function () {
  console.log('33333')

  function aa() {
    alert('3333')
  }
})